// 推荐网站数据 — 由编辑器维护
// 格式: [{ category: '分类名', icon: '🎨', items: [{ name: '站名', desc: '描述', url: 'https://...', icon: '🔗' }] }]
const SITE_LINKS = [
    {
        "category": "实用工具",
        "icon": "📌",
        "items": [
            {
                "name": "aix下载器",
                "desc": "一键检测网页的图片、视频、文档，并且下载",
                "url": "https://aixdownloader.com/zh/",
                "icon": "⬇️"
            },
            {
                "name": "抠图网",
                "desc": "上传图片自动识别主体，一键扣白底图",
                "url": "https://www.koukoutu.com/",
                "icon": "🦊"
            },
            {
                "name": "视频解析",
                "desc": "各大平台的视频图片解析，无水印下载",
                "url": "https://www.idaohang123.com/",
                "icon": "🌐"
            },
            {
                "name": "微信对话生成器",
                "desc": "在线生成微信对话、微信账单、微信零钱等界面截图，界面设置高度自由，真假难辨",
                "url": "https://vjietu.pro/",
                "icon": "🎲"
            },
            {
                "name": "PDF24",
                "desc": "非常强大且全能的pdf处理工具，完全免费，但有时下载速度会有点慢",
                "url": "https://tools.pdf24.org/zh/",
                "icon": "📫"
            },
            {
                "name": "文件转换",
                "desc": "支持上百种文件格式的自由转换",
                "url": "https://convertio.co/zh/",
                "icon": "⚡"
            },
            {
                "name": "文件压缩",
                "desc": "支持各种文件的压缩，减小体积",
                "url": "https://freecompress.com/zh-cn",
                "icon": "📦"
            }
        ]
    },
    {
        "category": "设计资源",
        "icon": "🎨",
        "items": [
            {
                "name": "设计师灵感",
                "desc": "设计师作品展示平台，灵感来源",
                "url": "https://dribbble.com/",
                "icon": "🏀"
            },
            {
                "name": "图标插画库",
                "desc": "阿里巴巴矢量图标库，海量免费图标",
                "url": "https://www.iconfont.cn/",
                "icon": "🎯"
            },
            {
                "name": "图片素材库",
                "desc": "高质量免费图片素材，商用无忧",
                "url": "https://unsplash.com/",
                "icon": "📷"
            },
            {
                "name": "字体天下",
                "desc": "免费可商用字体下载",
                "url": "https://www.fonts.net.cn/commercial-free/fonts-zh-4.html",
                "icon": "🖌️"
            }
        ]
    },
    {
        "category": "免费电影",
        "icon": "🎬",
        "items": [
            {
                "name": "奈飞工厂",
                "desc": "最新欧美日韩剧免费看，蓝光画质，无广告",
                "url": "https://www.netflixgc.tv/",
                "icon": "🚀"
            }
        ]
    },
    {
        "category": "游戏资源",
        "icon": "🎮",
        "items": [
            {
                "name": "蒸汽游戏",
                "desc": "网站涵盖最新最热手机，平板，电脑三端游戏资源，免费下载，免费开完",
                "url": "https://www.steambk.com/",
                "icon": "🖥️"
            }
        ]
    },
    {
        "category": "小说资源",
        "icon": "🗺️",
        "items": [
            {
                "name": "365小说",
                "desc": "热门小说全本txt免费下载",
                "url": "http://www.shukuge.com/",
                "icon": "📋"
            },
            {
                "name": "知轩藏书",
                "desc": "热门小说全本txt免费下载",
                "url": "https://zxcs.zip/",
                "icon": "📱"
            }
        ]
    },
    {
        "category": "壁纸资源",
        "icon": "✨",
        "items": [
            {
                "name": "哲风壁纸",
                "desc": "海量高清4K壁纸免费下载（每天有次数限制）",
                "url": "https://haowallpaper.com/",
                "icon": "🖼️"
            }
        ]
    }
];
